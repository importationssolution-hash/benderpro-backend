// Serveur de test minimal - verifie si Binance/Bybit/Bitget/OKX repondent
// ou bloquent l'acces depuis la region ou ce service est deploye.
// N'a rien a voir avec Bender Pro - juste un diagnostic reseau.
const express = require('express');
const ccxt = require('ccxt');

const app = express();

async function testExchange(exchangeId) {
  const start = Date.now();
  try {
    const ExClass = ccxt[exchangeId];
    if (!ExClass) return { exchangeId, ok: false, error: 'Exchange inconnu dans ccxt' };
    const exchange = new ExClass({ enableRateLimit: true, timeout: 10000 });
    const markets = await exchange.loadMarkets();
    const pairCount = Object.keys(markets).length;
    return {
      exchangeId,
      ok: true,
      pairCount,
      ms: Date.now() - start,
      message: `OK - ${pairCount} paires trouvees`
    };
  } catch (e) {
    return {
      exchangeId,
      ok: false,
      ms: Date.now() - start,
      error: e.message,
      // Les blocages geographiques renvoient souvent ces mots-cles
      looksLikeGeoBlock: /restrict|unavailable|forbidden|451|eligib|region|blocked/i.test(e.message)
    };
  }
}

app.get('/', (req, res) => {
  res.json({ status: 'Test de geo-blocage - Bender Pro', usage: 'GET /test pour lancer le diagnostic' });
});

app.get('/test', async (req, res) => {
  const exchanges = ['binance', 'bybit', 'bitget', 'okx', 'coinbase', 'kraken'];
  console.log('=== Debut du test geo-blocage ===');

  const results = [];
  for (const id of exchanges) {
    console.log(`Test de ${id}...`);
    const r = await testExchange(id);
    console.log(`  -> ${r.ok ? 'OK' : 'BLOQUE/ERREUR'}: ${r.message || r.error}`);
    results.push(r);
  }

  const summary = {
    region: process.env.RENDER_REGION || 'inconnue (variable RENDER_REGION non definie)',
    timestamp: new Date().toISOString(),
    results
  };

  console.log('=== Fin du test ===');
  res.json(summary);
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Serveur de test geo-blocage demarre sur le port ${PORT}`);
  console.log(`Va sur /test pour lancer le diagnostic (ex: https://ton-service.onrender.com/test)`);
});
